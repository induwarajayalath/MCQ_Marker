folder_path = "./assignments"
expected_answer = b"1\n2\n3\n4"
marks_for_correct_answer = 20
marks_for_compilation = 10

include_statements = ["if", "while"]
marks_include_statements = 30
exclude_statements = ["scanf", "for"]
marks_exclude_statements = 30

no_of_ifs = 1
marks_for_ifs = 20
no_of_whiles = 3
marks_for_whiles = 10
no_of_fors = 3
marks_for_fors = 10
